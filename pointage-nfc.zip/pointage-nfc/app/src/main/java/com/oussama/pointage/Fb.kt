package com.oussama.pointage

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class FbError(msg: String) : Exception(msg)

typealias Doc = Pair<String, Map<String, String>>

class Fb(val projectId: String, val apiKey: String, val email: String, val password: String) {
    private var cachedToken: String? = null
    private var tokenAt = 0L

    private fun http(method: String, url: String, body: String?, auth: Boolean): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.requestMethod = if (method == "PATCH") "POST" else method
        if (method == "PATCH") c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        c.setRequestProperty("Content-Type", "application/json")
        if (auth) c.setRequestProperty("Authorization", "Bearer " + token())
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    private fun token(): String {
        val now = System.currentTimeMillis()
        val t = cachedToken
        if (t != null && now - tokenAt < 50 * 60 * 1000) return t
        val body = JSONObject().put("email", email).put("password", password)
            .put("returnSecureToken", true).toString()
        val r = http(
            "POST",
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + apiKey,
            body, false
        )
        if (r.first != 200) throw FbError("login")
        val tk = JSONObject(r.second).getString("idToken")
        cachedToken = tk
        tokenAt = now
        return tk
    }

    private fun base() = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents"

    private fun fields(d: JSONObject): Map<String, String> {
        val f = d.optJSONObject("fields") ?: return emptyMap()
        val m = HashMap<String, String>()
        for (k in f.keys()) {
            val v = f.getJSONObject(k)
            m[k] = v.optString("stringValue", "")
        }
        return m
    }

    private fun encode(data: Map<String, String>): String {
        val f = JSONObject()
        for ((k, v) in data) f.put(k, JSONObject().put("stringValue", v))
        return JSONObject().put("fields", f).toString()
    }

    fun get(path: String): Map<String, String>? {
        val r = http("GET", base() + "/" + path, null, true)
        if (r.first == 404) return null
        if (r.first != 200) throw FbError("get " + r.first)
        return fields(JSONObject(r.second))
    }

    fun set(path: String, data: Map<String, String>) {
        val mask = data.keys.joinToString("&") { "updateMask.fieldPaths=$it" }
        val r = http("PATCH", base() + "/" + path + "?" + mask, encode(data), true)
        if (r.first !in 200..299) throw FbError("set " + r.first)
    }

    fun delete(path: String) {
        val r = http("DELETE", base() + "/" + path, null, true)
        if (r.first !in 200..299 && r.first != 404) throw FbError("delete " + r.first)
    }

    fun list(collection: String): List<Doc> {
        val out = ArrayList<Doc>()
        var pageToken: String? = null
        do {
            val url = base() + "/" + collection + "?pageSize=300" +
                (if (pageToken != null) "&pageToken=" + pageToken else "")
            val r = http("GET", url, null, true)
            if (r.first != 200) throw FbError("list " + r.first)
            val j = JSONObject(r.second)
            val arr = j.optJSONArray("documents")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val d = arr.getJSONObject(i)
                    out.add(Pair(d.getString("name").substringAfterLast('/'), fields(d)))
                }
            }
            val next = j.optString("nextPageToken", "")
            pageToken = if (next.isEmpty()) null else next
        } while (pageToken != null)
        return out
    }

    fun queryEq(collection: String, field: String, value: String): List<Doc> {
        val q = JSONObject().put(
            "structuredQuery", JSONObject()
                .put("from", JSONArray().put(JSONObject().put("collectionId", collection)))
                .put(
                    "where", JSONObject().put(
                        "fieldFilter", JSONObject()
                            .put("field", JSONObject().put("fieldPath", field))
                            .put("op", "EQUAL")
                            .put("value", JSONObject().put("stringValue", value))
                    )
                )
        )
        val r = http("POST", base() + ":runQuery", q.toString(), true)
        if (r.first != 200) throw FbError("query " + r.first)
        val arr = JSONArray(r.second)
        val out = ArrayList<Doc>()
        for (i in 0 until arr.length()) {
            val d = arr.getJSONObject(i).optJSONObject("document") ?: continue
            out.add(Pair(d.getString("name").substringAfterLast('/'), fields(d)))
        }
        return out
    }
}
