package com.oussama.pointage

import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime

fun dailyEarnings(date: LocalDate, start: LocalTime, end: LocalTime, rate: Double): Double {
    val base = when (date.dayOfWeek) {
        DayOfWeek.SATURDAY -> 1.25
        DayOfWeek.SUNDAY -> 1.75
        else -> 1.0
    }
    var total = Duration.between(start, end).toMinutes()
    if (total < 0) total += 1440
    val startMin = start.hour * 60 + start.minute
    var sum = 0.0
    for (i in 0 until total.toInt()) {
        val minuteOfDay = (startMin + i) % 1440
        var mult = base
        if (i >= 480) mult = maxOf(mult, 1.25)
        if (minuteOfDay >= 17 * 60) mult = maxOf(mult, 1.25)
        sum += mult / 60.0
    }
    return sum * rate
}

fun hoursBetween(a: LocalTime, b: LocalTime): Double {
    var m = Duration.between(a, b).toMinutes()
    if (m < 0) m += 1440
    return m / 60.0
}
