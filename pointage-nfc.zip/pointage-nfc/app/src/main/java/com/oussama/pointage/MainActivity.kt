package com.oussama.pointage

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class Res(val ok: Boolean, val msg: String, val card: String)

class MainActivity : Activity(), NfcAdapter.ReaderCallback {

    private var nfc: NfcAdapter? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var banner: TextView
    private var lastView: TextView? = null
    private var lang = "ar"
    private var screen = "kiosk"
    private var kiosk: Fb? = null
    private var admin: Fb? = null
    private var pairing: ((String) -> Unit)? = null
    private var lastCard = ""
    private var lastUid = ""
    private var lastAt = 0L
    private var monthOffset = 0
    private var workers: List<Doc> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")

    private fun t(k: String): String = STR[lang]?.get(k) ?: STR["en"]?.get(k) ?: k

    // ---------- lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pointage", MODE_PRIVATE)
        lang = prefs.getString("lang", "ar") ?: "ar"
        nfc = NfcAdapter.getDefaultAdapter(this)
        kiosk = loadKiosk()
        if (kiosk == null) showSettings() else showKiosk()
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfc
        if (adapter == null || !adapter.isEnabled) {
            alert(false, t("nfc_off"))
            return
        }
        adapter.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    override fun onPause() {
        super.onPause()
        nfc?.disableReaderMode(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "form", "detail" -> showAdmin()
            "admin" -> showKiosk()
            "settings" -> if (kiosk != null) showKiosk() else super.onBackPressed()
            else -> super.onBackPressed()
        }
    }

    private fun loadKiosk(): Fb? {
        val pid = prefs.getString("pid", "") ?: ""
        val key = prefs.getString("api", "") ?: ""
        val em = prefs.getString("kemail", "") ?: ""
        val pw = prefs.getString("kpw", "") ?: ""
        return if (pid.isEmpty() || key.isEmpty() || em.isEmpty() || pw.isEmpty()) null
        else Fb(pid, key, em, pw)
    }

    // ---------- NFC ----------

    override fun onTagDiscovered(tag: Tag) {
        val uid = tag.id.joinToString("") { "%02X".format(it) }
        runOnUiThread {
            val now = System.currentTimeMillis()
            if (uid == lastUid && now - lastAt < 5000) return@runOnUiThread
            lastUid = uid
            lastAt = now
            val p = pairing
            if (p != null) {
                p(uid)
            } else if (screen == "kiosk") {
                handleKiosk(uid)
            }
        }
    }

    private fun handleKiosk(uid: String) {
        val fb = kiosk ?: return
        async({
            val w = fb.get("workers/$uid")
            if (w == null) {
                Res(false, t("unknown"), "")
            } else {
                val head = (w["name"] ?: "") + "  (" + (w["mat"] ?: "") + ")"
                val today = LocalDate.now().toString()
                val id = uid + "_" + today
                val a = fb.get("attendance/$id")
                val now = LocalTime.now().withNano(0)
                val nowStr = now.format(timeFmt)
                if (a == null) {
                    fb.set("attendance/$id", mapOf("uid" to uid, "date" to today, "in" to now.toString()))
                    Res(true, head + "\n" + t("in_ok") + " " + nowStr, head + "\n" + t("in_l") + ": " + nowStr)
                } else if ((a["out"] ?: "").isEmpty()) {
                    val tin = LocalTime.parse(a["in"] ?: now.toString())
                    if (java.time.Duration.between(tin, now).toMinutes() < 1) {
                        Res(false, head + "\n" + t("wait"), "")
                    } else {
                        fb.set("attendance/$id", mapOf("out" to now.toString()))
                        Res(
                            true, head + "\n" + t("out_ok") + " " + nowStr,
                            head + "\n" + t("in_l") + ": " + tin.format(timeFmt) + "   " + t("out_l") + ": " + nowStr
                        )
                    }
                } else {
                    Res(false, head + "\n" + t("done"), "")
                }
            }
        }) { r ->
            alert(r.ok, r.msg)
            if (r.card.isNotEmpty()) {
                lastCard = r.card
                lastView?.text = lastCard
                lastView?.visibility = View.VISIBLE
            }
        }
    }

    // ---------- helpers ----------

    private fun <T> async(work: () -> T, done: (T) -> Unit) {
        Thread {
            try {
                val r = work()
                runOnUiThread { done(r) }
            } catch (e: Exception) {
                runOnUiThread { alert(false, errMsg(e)) }
            }
        }.start()
    }

    private fun errMsg(e: Exception): String = when {
        e is FbError && e.message == "login" -> t("err_login")
        e is IOException -> t("err_net")
        else -> t("err_srv") + "\n" + (e.message ?: "")
    }

    private fun alert(ok: Boolean, msg: String) {
        if (!::banner.isInitialized) return
        banner.text = msg
        banner.setBackgroundColor(if (ok) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
        banner.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ banner.visibility = View.GONE }, 4000)
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (ok) {
                v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
            }
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            tg.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 400)
            Handler(Looper.getMainLooper()).postDelayed({ tg.release() }, 900)
        } catch (e: Exception) {
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun styledButton(text: String, color: Int) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 16f
        background = rounded(color, 14)
    }

    private fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = type
        setTextColor(0xFF1A2B3C.toInt())
        setHintTextColor(0xFF90A4AE.toInt())
    }

    private fun whiteCard(text: String, size: Float = 17f) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFF1A2B3C.toInt())
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.WHITE, 18)
    }

    private fun page(title: String): LinearLayout {
        window.statusBarColor = 0xFF0F2027.toInt()
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
            layoutDirection = if (lang == "ar") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        banner = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(18))
            visibility = View.GONE
        }
        outer.addView(banner)
        val sv = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        sv.addView(root)
        outer.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tv = TextView(this).apply {
            text = title
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        header.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val nextLang = when (lang) { "ar" -> "fr"; "fr" -> "en"; else -> "ar" }
        val nextLabel = when (nextLang) { "ar" -> "العربية"; "fr" -> "Français"; else -> "English" }
        val langBtn = styledButton(nextLabel, 0x33FFFFFF)
        langBtn.setOnClickListener {
            lang = nextLang
            prefs.edit().putString("lang", nextLang).apply()
            reshow()
        }
        header.addView(langBtn)
        root.addView(header)
        setContentView(outer)
        return root
    }

    private fun reshow() {
        when (screen) {
            "settings" -> showSettings()
            "admin" -> showAdmin()
            else -> showKiosk()
        }
    }

    // ---------- settings ----------

    private fun showSettings() {
        screen = "settings"
        pairing = null
        lastView = null
        val root = page(t("settings"))
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = rounded(Color.WHITE, 18)
        }
        val ePid = field(t("pid"), prefs.getString("pid", "") ?: "")
        val eApi = field(t("api"), prefs.getString("api", "") ?: "")
        val eMail = field(t("kemail"), prefs.getString("kemail", "") ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val ePw = field(t("kpw"), prefs.getString("kpw", "") ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        form.addView(ePid); form.addView(eApi); form.addView(eMail); form.addView(ePw)
        root.addView(form, lp(12))
        val save = styledButton(t("save_test"), 0xFF00897B.toInt())
        save.setOnClickListener {
            prefs.edit()
                .putString("pid", ePid.text.toString().trim())
                .putString("api", eApi.text.toString().trim())
                .putString("kemail", eMail.text.toString().trim())
                .putString("kpw", ePw.text.toString())
                .apply()
            kiosk = loadKiosk()
            val fb = kiosk
            if (fb != null) {
                async({ fb.get("workers/_ping"); true }) {
                    showKiosk()
                    alert(true, t("connected"))
                }
            }
        }
        root.addView(save, lp(12))
        if (kiosk != null) {
            val back = styledButton(t("back"), 0xFF546E7A.toInt())
            back.setOnClickListener { showKiosk() }
            root.addView(back, lp(8))
        }
    }

    // ---------- kiosk ----------

    private fun showKiosk() {
        screen = "kiosk"
        pairing = null
        admin = null
        val root = page("Pointage")
        root.addView(whiteCard(t("tap_badge"), 22f).apply { gravity = Gravity.CENTER }, lp(16))
        val last = whiteCard(lastCard, 17f)
        last.visibility = if (lastCard.isEmpty()) View.GONE else View.VISIBLE
        lastView = last
        root.addView(last, lp(12))
        val adminBtn = styledButton(t("admin"), 0xFF00897B.toInt())
        adminBtn.setOnClickListener { adminLogin() }
        val setBtn = styledButton(t("settings"), 0xFF546E7A.toInt())
        setBtn.setOnClickListener { showSettings() }
        root.addView(adminBtn, lp(24))
        root.addView(setBtn, lp(8))
    }

    private fun adminLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val eMail = field(t("email"), prefs.getString("aemail", "") ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val ePw = field(t("password"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        box.addView(eMail)
        box.addView(ePw)
        AlertDialog.Builder(this)
            .setTitle(t("admin"))
            .setView(box)
            .setPositiveButton(t("ok")) { _, _ ->
                val k = kiosk
                if (k != null) {
                    val email = eMail.text.toString().trim()
                    prefs.edit().putString("aemail", email).apply()
                    val fb = Fb(k.projectId, k.apiKey, email, ePw.text.toString())
                    async({ fb.list("workers") }) { list ->
                        admin = fb
                        workers = list
                        showAdmin()
                    }
                }
            }
            .setNegativeButton(t("cancel"), null)
            .show()
    }

    // ---------- admin ----------

    private fun showAdmin() {
        val fb = admin
        if (fb == null) {
            showKiosk()
            return
        }
        screen = "admin"
        pairing = null
        lastView = null
        val root = page(t("workers"))
        val add = styledButton(t("add_worker"), 0xFF00897B.toInt())
        add.setOnClickListener { showForm(null) }
        val back = styledButton(t("back"), 0xFF546E7A.toInt())
        back.setOnClickListener { showKiosk() }
        root.addView(add, lp(12))
        root.addView(back, lp(8))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(box, lp(8))
        val loading = TextView(this).apply { text = t("loading"); setTextColor(Color.WHITE) }
        box.addView(loading)
        async({ fb.list("workers") }) { list ->
            workers = list
            box.removeAllViews()
            if (list.isEmpty()) {
                box.addView(TextView(this).apply { text = t("no_workers"); setTextColor(Color.WHITE) })
            }
            for (w in list.sortedBy { (it.second["name"] ?: "").lowercase() }) {
                box.addView(TextView(this).apply {
                    text = (w.second["name"] ?: "?") + "\n" + t("mat") + ": " + (w.second["mat"] ?: "—")
                    textSize = 17f
                    setTextColor(Color.WHITE)
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    background = rounded(0x22FFFFFF, 12)
                    setOnClickListener { showDetail(w.first) }
                }, lp(8))
            }
        }
    }

    private fun showForm(editId: String?) {
        val fb = admin ?: return showKiosk()
        screen = "form"
        lastView = null
        val cur = workers.firstOrNull { it.first == editId }?.second ?: emptyMap()
        val root = page(if (editId == null) t("add_worker") else t("edit_worker"))
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = rounded(Color.WHITE, 18)
        }
        val eName = field(t("hint_name"), cur["name"] ?: "")
        val eMat = field(t("hint_mat"), cur["mat"] ?: "")
        val eRate = field(t("hint_rate"), cur["rate"] ?: "", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        form.addView(eName); form.addView(eMat); form.addView(eRate)
        root.addView(form, lp(12))

        var uid = editId ?: ""
        val uidView = whiteCard(t("badge") + ": " + (if (uid.isEmpty()) "—" else uid), 16f)
        root.addView(uidView, lp(12))
        if (editId == null) {
            val scan = styledButton(t("scan_badge"), 0xFF3949AB.toInt())
            scan.setOnClickListener {
                alert(true, t("no_badge"))
                pairing = { u ->
                    pairing = null
                    uid = u
                    uidView.text = t("badge") + ": " + u
                    alert(true, t("badge_read"))
                }
            }
            root.addView(scan, lp(8))
        }
        val save = styledButton(t("save"), 0xFF00897B.toInt())
        save.setOnClickListener {
            val name = eName.text.toString().trim()
            if (name.isEmpty() || uid.isEmpty()) {
                alert(false, t("need_fields"))
                return@setOnClickListener
            }
            val data = hashMapOf(
                "name" to name,
                "mat" to eMat.text.toString().trim(),
                "rate" to eRate.text.toString().trim().replace(',', '.')
            )
            if (editId == null) data["start"] = LocalDate.now().toString()
            async({
                if (editId == null && fb.get("workers/$uid") != null) {
                    false
                } else {
                    fb.set("workers/$uid", data)
                    true
                }
            }) { ok ->
                if (ok) {
                    pairing = null
                    showAdmin()
                    alert(true, t("saved"))
                } else {
                    alert(false, t("badge_used"))
                }
            }
        }
        root.addView(save, lp(12))
        if (editId != null) {
            val del = styledButton(t("delete_worker"), 0xFFC62828.toInt())
            del.setOnClickListener {
                async({ fb.delete("workers/$editId") }) {
                    showAdmin()
                    alert(true, t("saved"))
                }
            }
            root.addView(del, lp(8))
        }
        val back = styledButton(t("back"), 0xFF546E7A.toInt())
        back.setOnClickListener { pairing = null; showAdmin() }
        root.addView(back, lp(8))
    }

    private fun showDetail(uid: String) {
        val fb = admin ?: return showKiosk()
        screen = "detail"
        pairing = null
        lastView = null
        val w = workers.firstOrNull { it.first == uid }?.second ?: emptyMap()
        val root = page(w["name"] ?: "?")
        val rate = (w["rate"] ?: "").toDoubleOrNull() ?: 0.0
        val cur = t("cur")
        val ym = YearMonth.now().plusMonths(monthOffset.toLong())

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val prev = styledButton("‹", 0x33FFFFFF).apply { setOnClickListener { monthOffset--; showDetail(uid) } }
        val next = styledButton("›", 0x33FFFFFF).apply {
            isEnabled = monthOffset < 0
            setOnClickListener { monthOffset++; showDetail(uid) }
        }
        val label = TextView(this).apply {
            text = ym.month.getDisplayName(TextStyle.FULL, Locale(lang)) + " " + ym.year
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        nav.addView(prev)
        nav.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(next)
        root.addView(nav, lp(12))

        val summary = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(4))
            text = t("loading")
        }
        root.addView(summary)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(box)

        val edit = styledButton(t("edit_worker"), 0xFF3949AB.toInt())
        edit.setOnClickListener { showForm(uid) }
        val back = styledButton(t("back"), 0xFF546E7A.toInt())
        back.setOnClickListener { showAdmin() }
        root.addView(edit, lp(16))
        root.addView(back, lp(8))

        async({ fb.queryEq("attendance", "uid", uid) }) { docs ->
            val rec = HashMap<String, Map<String, String>>()
            for (d in docs) rec[d.second["date"] ?: ""] = d.second
            val today = LocalDate.now()
            val monthStart = ym.atDay(1)
            val startD = (w["start"] ?: "").let { if (it.isEmpty()) monthStart else LocalDate.parse(it) }
            val from = if (startD.isAfter(monthStart)) startD else monthStart
            val lastDay = if (ym == YearMonth.now()) today else ym.atEndOfMonth()
            var totalH = 0.0
            var totalE = 0.0
            var absences = 0
            var d = lastDay
            while (!d.isBefore(from)) {
                val r = rec[d.toString()]
                val tin = r?.get("in")?.takeIf { it.isNotEmpty() }?.let { LocalTime.parse(it) }
                val tout = r?.get("out")?.takeIf { it.isNotEmpty() }?.let { LocalTime.parse(it) }
                val dayName = d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale(lang))
                val line = StringBuilder("${d.dayOfMonth}/${d.monthValue} $dayName: ")
                var color = Color.WHITE
                if (tin != null) {
                    val end = tout ?: if (d == today) LocalTime.now() else tin
                    val h = hoursBetween(tin, end)
                    val e = dailyEarnings(d, tin, end, rate)
                    totalH += h
                    totalE += e
                    line.append("${tin.format(timeFmt)} → ${tout?.format(timeFmt) ?: "..."}  ")
                        .append("${f(h)} ${t("h")}  ${f(e)} $cur")
                } else {
                    val weekend = d.dayOfWeek == DayOfWeek.SATURDAY || d.dayOfWeek == DayOfWeek.SUNDAY
                    when {
                        d == today -> { line.append("—"); color = 0xFFB0BEC5.toInt() }
                        weekend -> { line.append(t("rest")); color = 0xFFB0BEC5.toInt() }
                        else -> { absences++; line.append(t("absent")); color = 0xFFFF8A80.toInt() }
                    }
                }
                val day = d
                box.addView(TextView(this).apply {
                    text = line.toString()
                    textSize = 15f
                    setTextColor(color)
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = rounded(0x22FFFFFF, 12)
                    setOnClickListener { dayMenu(uid, day, tin, tout) }
                }, lp(8))
                d = d.minusDays(1)
            }
            summary.text = "${t("month")}\n${t("hours")}: ${f(totalH)}\n${t("earn_total")}: ${f(totalE)} $cur\n${t("absences")}: $absences"
        }
    }

    private fun f(x: Double) = String.format(Locale.US, "%.2f", x)

    private fun dayMenu(uid: String, d: LocalDate, tin: LocalTime?, tout: LocalTime?) {
        val fb = admin ?: return
        AlertDialog.Builder(this)
            .setTitle("${d.dayOfMonth}/${d.monthValue}")
            .setItems(arrayOf(t("edit_times"), t("clear_day"))) { _, which ->
                if (which == 0) {
                    pick(t("pick_in"), tin ?: LocalTime.of(8, 0)) { newIn ->
                        pick(t("pick_out"), tout ?: LocalTime.of(16, 0)) { newOut ->
                            async({
                                fb.set(
                                    "attendance/${uid}_$d",
                                    mapOf("uid" to uid, "date" to d.toString(), "in" to newIn.toString(), "out" to newOut.toString())
                                )
                            }) { showDetail(uid) }
                        }
                    }
                } else {
                    async({ fb.delete("attendance/${uid}_$d") }) { showDetail(uid) }
                }
            }
            .show()
    }

    private fun pick(title: String, init: LocalTime, onDone: (LocalTime) -> Unit) {
        val dlg = TimePickerDialog(this, { _, h, m -> onDone(LocalTime.of(h, m)) }, init.hour, init.minute, true)
        dlg.setTitle(title)
        dlg.show()
    }
}
